Advanced Buttons is by far the most advanced and customizable Button/Custom command addon for corebot. Create your very own custom commands that have the option for buttons to give/take roles, coins, xp & more.

With unlimited buttons & responses your able to take your custom commands to the next level. Create custom help menus, custom verification panels, reaction role menus and more!


Features:


General:

-Create Unlimited Buttons/Button groups/Custom commands
-All embeds use Advanced Say Formatting.
-Send multiple messages on button click. With support for unlimited responses.
-Require a specific role to run a Custom Command/On reaction
-Send the original button as a Webhook. (Cannot Edit Message)
	Customize PFP
	Customize Name

Buttons:

-Multiple Button Formats. List
-Custom Title for each button
-Required Role to click the button
-Open link support
-Join channel Support
-Cooldown for clicking buttons. EX: 1s 1m, 1h, 1d
-Given Rewards
	Roles
	Coins
	XP
-Taken Rewards
	Roles
	Coins
	XP
-Unlimited Responses on click

Responses:

-Supports Multiple Responses
-Multiple Response Types
	REPLY = reply to the original message
	DM = DM the user who clicked the button
	CHANNEL = send a new message in the channel
	EDIT = edit the original message with new buttons/embed/content
	Channel ID/Name = send the new message in a specific channel.
-Send REPLY messages as Private so only the member can see it.
-Delete responses after x milliseconds. EX: Delete: 3500 (3.5s)
-Send MORE buttons with the new response (These buttons can have MORE responses)

API:

-findButton - find a button by Custom_ID
-getEnd - Get a cooldown end
-getAdvancedEmbed - Convert Advanced Say String to Embed/Text
-formatButtons - Convert config buttons to messageComponents array
-createWebhook - Create a custom webhook in a channel. Used for getWebhook function
-getWebhook - Find & create a custom webhook in a channel
-sendButton - Send the embed/text/buttons to a channel, accept variables, webhooks
-sendPing - Send a ping response to a interaction
-sendReply - Reply to a interaction with a new Message
-sendResponses - Send a array of responses when a button is clicked
-edit - Edit the buttons message with new content